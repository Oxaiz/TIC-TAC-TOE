
import './App.css';
import TicTacToe from './Components/TicTacToe/TicTacToe';



function App() {
  return( 
  <div>
    <TicTacToe msg = "MUHAMMAD OWAIS - 22BCE2317"/>
    </div>
);
  }

export default App;
